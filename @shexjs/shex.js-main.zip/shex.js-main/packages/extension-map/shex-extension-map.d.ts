export = shexjs__extension_map;

declare function shexjs__extension_map(config: any): any;


