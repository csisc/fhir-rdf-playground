# default uploads dir for REST server

The server erases files after it uploads and validates with them.
Barring crashes and interruptions (e.g. in the debugger), this directory should always be empty.
If not, wipe out everything except for this README.md (or maybe get rid of it too if it's served its purpose).

Happy validating!
