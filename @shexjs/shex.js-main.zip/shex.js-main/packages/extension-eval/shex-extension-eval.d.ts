export {};

export const description: string;

export const name: string;

export const url: string;

export function done(validator: any): void;

export function register(validator: any, api: any): any;


