export function shapePathQuery(schema: any, nodeSet: any, db: any, smap: any): any;


