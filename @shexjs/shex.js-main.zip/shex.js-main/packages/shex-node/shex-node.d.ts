export = shexjs__node;

declare function shexjs__node(config: any): any;


