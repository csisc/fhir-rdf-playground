export = shexjs__loader;

declare function shexjs__loader(config: any): any;


