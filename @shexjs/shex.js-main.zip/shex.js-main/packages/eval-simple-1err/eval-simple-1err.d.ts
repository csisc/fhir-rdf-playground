export const description: string;

export const name: string;

export function compile(schema: any, shape: any, index: any): any;


